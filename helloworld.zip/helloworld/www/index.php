<?php
	$XTITLE = 'Hello World!';
?>
<html>
<head>
<title>
<?php echo $XTITLE; ?>
</title>
</head>
<body>

<?php echo $XTITLE; ?>

</body>
</html>
